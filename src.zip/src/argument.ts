module Marmot{
    export abstract class Argument extends SyntaxElement{

        constructor(){
            super();
        }
    }
}
